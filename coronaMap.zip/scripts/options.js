export const options = {
  strokeColor: 0,
  strokeColorSelected: 360,
  fillColor: 240,
  fillColorSelected: 360,
  fillSelectedCounties: true,
  borderStrokeWidth: 0.002,
  borderStrokeWidthSelected: 0.01,
  barColor: 240,
  numberOfBars: 20
}
